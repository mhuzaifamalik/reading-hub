import React from 'react'

function BloggerProfileSuccess() {
    return (
        <div>
            <section className="main-success">
                <div className="container">
                    <h2 className=''>Blogger Profile Successfully Created</h2>

                    <button>Log in</button>
                </div>
            </section>
        </div>
    )
}

export default BloggerProfileSuccess
