import React from 'react'
import From from '../components/form'

function contact() {
  return (
    <div>
      <section className="contact-section">|

        <From />
      </section>
    </div>
  )
}

export default contact
