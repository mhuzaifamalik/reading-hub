import React from 'react'
import Profiles from '../components/profiles'


function profilePages() {
    return (
        <div>
            <Profiles subtitle="Drama" desc="A gripping journey into the heart of theatrical passion and rivalry." Heading="Shadows Over the Stage" />
            
        </div>
    )
}

export default profilePages
