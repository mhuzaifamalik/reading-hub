import React from 'react'
import Product from '../components/ourproducts'
function ProductPage() {
  return (
    <div>
      <div className="products-page">
            <Product subtitle="Drama" desc="A gripping journey into the heart of theatrical passion and rivalry." Heading="Shadows Over the Stage" />
      </div>
    </div>
  )
}

export default ProductPage
