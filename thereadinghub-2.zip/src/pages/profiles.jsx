import React from 'react'
import Blog from '../components/bloggingPost'


function profiles() {
  return (
    <div>
   <section className='bloggingCard'>
       <Blog />
   </section>
    </div>
  )
}

export default profiles
